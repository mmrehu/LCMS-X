<?php
$url = isset($_GET['url']) ? $_GET['url'] : 'https://example.com';
?>