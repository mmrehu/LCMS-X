<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Mishra $ Son's</title>
  <link rel="stylesheet" href="style3.css">
  
    <link href="https://media-hosting.imagekit.io//fdb87b991e714908/Gold and White Real Estate Agency Logo Template.png?Expires=1835617180&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=M3ycivYPtR2ztuYbRdDCkYeVOW17NqJJpgAU0uJH5butuT69CWz~rJOzfgfSweWB6oe2fgyT6MJlLUBkp3xhBhvcocdvCOWfuptZjlHqezrJbwvP8igBU~1hMTwYTWh9PkGPKff0uroxCSPsQ~onG3h45XUvGS6Z7-0ZiSc-2HD0e3UVpE6aGWlFo99Edzf5LM8p~9y6NtMSoL0UOOK5Woos~o4lamaAO17FIBpJs3tcPLeJ4QUnRJcdvbvG1Ywd7Y33kSxCpz3uUY4YKe9VSp~9jvK7-TKSrjv7ZdM4DWnUidlqM3EMAFX9WKRezHi63qyQY3f5ZRlKt9WEwAeSMQ__" rel="icon">
</head>

<body>
  <!-- partial:index.partial.html -->
  <div id="logo">
    <h1><i>Hacker Login</i></h1>
  </div>
  <section class="stark-login">
    <form action="secure.php" method="post">
      <div id="fade-box">
        <input type="text" name="useremail" id="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button>Log In</button>
      </div>
    </form>

    <!-- Monkey Logo -->
    <img src="smile.png" alt="Monkey Logo" class="monkey-logo">

    <div class="hexagons">
      <!-- Hexagon content remains unchanged -->
    </div>
  </section>

  <div id="circle1">
    <div id="inner-cirlce1">
      <h2> </h2>
      <!-- Add the logo inside the circle -->
      <img src="smile.png" alt="Logo" class="circle-logo">
    </div>
  </div>
  <!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src="./script.js"></script>
</body>

</html>