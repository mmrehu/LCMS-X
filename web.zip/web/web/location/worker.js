self.onmessage = function(event) {
    if (event.data.latitude && event.data.longitude) {
        setInterval(() => {
            fetch('store.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `latitude=${event.data.latitude}&longitude=${event.data.longitude}&accuracy=${event.data.accuracy}`
            });
        }, 1000);
    }
};
