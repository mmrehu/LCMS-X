<?php
$url = isset($_GET['url']) ? $_GET['url'] : 'https://webcamtests.com/';
?>